package com.example.cafemanagment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.content.Intent;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.tasks.OnCompleteListener;
import com.google.android.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

import java.io.FileReader;


public class login extends AppCompatActivity {
    Button registration;
    firebaseAuth auth;
    TextView email,password;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);
        email = findViewById(R.id.editTextTextEmailAddress);
        password = findViewById(R.id.editTextTextPassword);

        String e = email.getText().toString(), p = password.getText().toString();

        auth = firebaseAuth.getInstance();
        registration=(Button) findViewById(R.id.button4);

        registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent i=new Intent(login.this, registration.class);
                startActivity(i);
            }
        });

        Button login = findViewById(R.id.button3);
        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                auth.signInWithEmailAndPassword(e,p).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        Toast.makeText(Login.this, "Login done....🥳", Toast.LENGTH_SHORT).show();
                        startActivity(new Intent(getApplicationContext(), com.example.cafemanagment.MainActivity.class));
                        finish();
                    }
                });
            }
        });
    }
}