package com.example.cafemanagment;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class splash_login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_splash_login);

        new Handler().postDelayed(new Runnable() {
                                      @Override
                                      public void run() {
                                          Intent i = new Intent(Splash_screen.this, MainActivity.class);
                                          startActivity(i);
                                      }
                                  }

                , 3000);
    }
    }
}