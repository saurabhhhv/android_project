package com.example.cafemanagment;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.view;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import com.example.cafemanagment.registration;
import com.google.android.tasks.OnCompleteListener;
import com.google.android.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.database.DatabaseRefrence;
import com.google.firebase.database.FirebaseDatabase;
import java.util.UUID;

public class registration extends AppCompatActivity {
    EditText Rfirstname,Rlastname,REmail,Rpassword,Registration;
    Button button4;
    FirebaseAuth fauth;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration);
        Rfirstname = (EditText) findViewById(R.id.editTextTextEmailAddress2);
        Rlastname = (EditText)findViewById(R.id.)
        REmail = (EditText) findViewById(R.id.editTextTextEmailAddress);
        Rpassword = (EditText) findViewById(R.id.editTextTextEmailAddress3);
        Registration = findViewById(R.id.button4);

        fauth = FirebaseAuth.getInstance();



        registration.setOnClickListener(new View.OnClickListener() {

            @Override
            public void onClick(View v) {
                String email = REmail.getText().toString();
                String password = Rpassword.getText().toString().trim();
                String username = Rusername.getText().toString().trim();
                String lastname =


                if(TextUtils.isEmpty(email)){
                    REmail.setError("Email is required");
                    return;
                }
                if(TextUtils.isEmpty(password)){
                    Rpassword.setError("Password is required");
                    return;
                }

                if(password.length()<6) {
                    Rpassword.setError("Password must be 6 character");
                }
                if(TextUtils.isEmpty(username)){
                    Rusername.setError("Username is required");
                    return;
                }
                if(TextUtils.isEmpty(confirm_password)){
                    Rconfirm_password.setError("Confirm Password is required");
                    return;
                }
                if(TextUtils.isEmpty(contact_no)){
                    Rcontact_no.setError("Contact No.` is required");
                    return;
                }

                fauth.createUserWithEmailAndPassword(email,password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                    @Override
                    public void onComplete(@NonNull Task<AuthResult> task) {
                        if (task.isSuccessful()) {
                            Toast.makeText(Registration.this, "Successful", Toast.LENGTH_SHORT).show();
                            DatabaseReference dbref = FirebaseDatabase.getInstance().getReference("Register");
                            String uid =  FirebaseAuth.getInstance().getUid().toString();
                            RegisterModal registerModal = new RegisterModal(username, email, contact_no,uid);
                            String rid = UUID.randomUUID().toString();
                            dbref.child(rid).setValue(registerModal);
                            startActivity(new Intent(getApplicationContext(), Login.class));
                        } else {
                            Toast.makeText(Registration.this, "Error! " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                        }
                    }
                });

                if(fauth.getCurrentUser() != null){
                    startActivity(new Intent(getApplicationContext(),MainActivity.class));
                    finish();
                }
            }
        });

    }
}
    }
}